"""pydisque makes access to Disque in python easy."""
